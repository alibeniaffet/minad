<script>
  import { onMount } from 'svelte';
  import { parseGIF, decompressFrames } from 'gifuct-js';
  import { getAvailableModels, parseWatchFaceBin, writeWatchFaceBin } from 'watchface-js/watchFaceBinParser';
  import { generatePreview } from 'watchface-js/previewGenerator';
  import { fitRect, pixelsFromCanvas, canvasFromPixels, downloadViaAndroid, clamp } from './utils';

  const W=126, H=294;
  let models=[]; let model; let parameters={}; let images=[]; let ready=false;
  let preview; let canvas; let mediaInput;
  let status={hours:12,minutes:34,seconds:0,steps:12882,stepsPercent:67,calories:3453,caloriesPercent:20,pulse:72,heartPercent:43,distance:4.2,pai:50,year:2026,month:10,day:7,pm:false,weekday:3,weather:5,currentTemperature:22,dayTemperature:25,nightTemperature:15,humidity:55,wind:8,uvi:3,doNotDisturb:false,lock:false,bluetooth:true,batteryPercent:76,alarmHours:7,alarmMinutes:0,alarmOnOff:false,animationTime:0,locale:{lang:'EN',imperial:false}};
  let error=''; let busy=false; let mediaName=''; let frameCount=12; let fps=10; let fit='cover'; let bg='black'; let removeWhite=true; let animationX=0; let animationY=0;
  let showTime=true; let timeX=22; let timeY=215; let timeScale=1;
  let showDate=false; let dateX=10; let dateY=10;
  let showBattery=false; let batteryX=10; let batteryY=260;
  let showSteps=false; let stepsX=10; let stepsY=275;
  let textLayers=[{text:'',x:10,y:20,size:14,color:'#ffffff'}];
  let advancedJson=''; let showAdvanced=false; let animationTimer;

  const bridge=()=>window.AndroidBridge;
  onMount(async()=>{ try{ models=getAvailableModels(); model=models.find(m=>m.id==='miband5')||models[0]; await loadTemplate(); ready=true; startPreviewLoop(); }catch(e){error=String(e);} });

  async function getTemplateBuffer(){
    if(bridge()?.getTemplateBase64){ const b64=bridge().getTemplateBase64(); const bin=atob(b64); const out=new Uint8Array(bin.length); for(let i=0;i<bin.length;i++)out[i]=bin.charCodeAt(i); return out.buffer; }
    const r=await fetch('template.bin'); return await r.arrayBuffer();
  }
  async function loadTemplate(){
    const buf=await getTemplateBuffer(); const parsed=parseWatchFaceBin(buf,model.fileType); parameters=parsed.parameters; images=parsed.images; advancedJson=JSON.stringify(parameters,null,2); syncControlsFromParameters(); }
  function syncControlsFromParameters(){
    const t=parameters?.['3:Time']; const h=t?.['1:Hours']?.['1:Tens']; if(h){timeX=h['1:X']??timeX;timeY=h['2:Y']??timeY;}
    const a=parameters?.['11:Other']?.['1:Animation']?.['1:AnimationImages']; if(a){animationX=a['1:X']??0;animationY=a['2:Y']??0;}
  }
  function updateTimePos(){ const t=parameters?.['3:Time']; if(!t)return; for(const k of ['1:Hours','2:Minutes']) for(const q of ['1:Tens','2:Ones']) if(t[k]?.[q]){t[k][q]['1:X']=Math.round(timeX);t[k][q]['2:Y']=Math.round(timeY);} if(t['5:DelimiterImage']){t['5:DelimiterImage']['1:X']=Math.round(timeX+48*timeScale);t['5:DelimiterImage']['2:Y']=Math.round(timeY);} advancedJson=JSON.stringify(parameters,null,2); }
  function updateAnimationPos(){ const a=parameters?.['11:Other']?.['1:Animation']?.['1:AnimationImages']; if(a){a['1:X']=Math.round(animationX);a['2:Y']=Math.round(animationY);} advancedJson=JSON.stringify(parameters,null,2); }

  function addText(){textLayers=[...textLayers,{text:'Yeni yazı',x:10,y:40,size:14,color:'#ffffff'}];}
  function removeText(i){textLayers=textLayers.filter((_,n)=>n!==i);}

  function floodRemoveWhite(data,w,h){
    const seen=new Uint8Array(w*h), qx=new Int32Array(w*h), qy=new Int32Array(w*h); let head=0,tail=0;
    const push=(x,y)=>{const i=y*w+x;if(seen[i])return; const p=i*4; if(data[p]>220&&data[p+1]>220&&data[p+2]>220){seen[i]=1;qx[tail]=x;qy[tail]=y;tail++;}};
    for(let x=0;x<w;x++){push(x,0);push(x,h-1);} for(let y=0;y<h;y++){push(0,y);push(w-1,y);}
    while(head<tail){const x=qx[head],y=qy[head++]; const p=(y*w+x)*4; data[p+3]=0; if(x)push(x-1,y);if(x<w-1)push(x+1,y);if(y)push(x,y-1);if(y<h-1)push(x,y+1);}
    return data;
  }
  function renderSourceToFrame(src,sw,sh){
    const c=document.createElement('canvas'); c.width=sw;c.height=sh; const ctx=c.getContext('2d',{willReadFrequently:true});
    const imgData=new ImageData(new Uint8ClampedArray(src),sw,sh); if(removeWhite) floodRemoveWhite(imgData.data,sw,sh); ctx.putImageData(imgData,0,0);
    const out=document.createElement('canvas');out.width=W;out.height=H;const o=out.getContext('2d');o.fillStyle=bg==='black'?'#000':'#fff';o.fillRect(0,0,W,H);
    const r=fitRect(sw,sh,W,H,fit); const x=Math.round((W-r.w)/2+animationX), y=Math.round((H-r.h)/2+animationY); o.imageSmoothingEnabled=true;o.imageSmoothingQuality='high';o.drawImage(c,x,y,r.w,r.h);
    for(const l of textLayers){if(!l.text)continue;o.font=`${Number(l.size)||14}px sans-serif`;o.fillStyle=l.color||'#fff';o.fillText(l.text,Number(l.x)||0,Number(l.y)||0);}
    return pixelsFromCanvas(out);
  }
  async function gifFrames(file){
    const buf=await file.arrayBuffer(); const gif=parseGIF(buf); const frames=decompressFrames(gif,true); const full=document.createElement('canvas'); full.width=gif.lsd.width;full.height=gif.lsd.height;const ctx=full.getContext('2d',{willReadFrequently:true});ctx.fillStyle=bg==='black'?'#000':'#fff';ctx.fillRect(0,0,full.width,full.height);const out=[];
    let previous=null;
    for(let i=0;i<frames.length;i++){
      const f=frames[i]; const before=ctx.getImageData(0,0,full.width,full.height); const patch=new ImageData(new Uint8ClampedArray(f.patch),f.dims.width,f.dims.height); const pc=document.createElement('canvas');pc.width=f.dims.width;pc.height=f.dims.height;pc.getContext('2d').putImageData(patch,0,0);ctx.drawImage(pc,f.dims.left,f.dims.top); const data=ctx.getImageData(0,0,full.width,full.height); out.push(renderSourceToFrame(data.data,full.width,full.height));
      if(f.disposalType===2){ctx.clearRect(f.dims.left,f.dims.top,f.dims.width,f.dims.height);ctx.fillStyle=bg==='black'?'#000':'#fff';ctx.fillRect(f.dims.left,f.dims.top,f.dims.width,f.dims.height);} else if(f.disposalType===3 && previous){ctx.putImageData(previous,0,0);} else if(f.disposalType===3){ctx.putImageData(before,0,0);} previous=before;
    }
    return out;
  }
  function seek(video,time){return new Promise((resolve)=>{const done=()=>{video.removeEventListener('seeked',done);resolve();};video.addEventListener('seeked',done);video.currentTime=time;});}
  async function videoFrames(file){
    const url=URL.createObjectURL(file);const v=document.createElement('video');v.preload='auto';v.muted=true;v.src=url;await new Promise((res,rej)=>{v.onloadedmetadata=res;v.onerror=rej;}); const n=Math.max(1,Math.min(frameCount,Math.ceil(v.duration*fps)));const out=[];for(let i=0;i<n;i++){await seek(v,Math.min(v.duration-0.001,i/fps));const c=document.createElement('canvas');c.width=v.videoWidth;c.height=v.videoHeight;c.getContext('2d').drawImage(v,0,0);out.push(renderSourceToFrame(c.getContext('2d').getImageData(0,0,c.width,c.height).data,c.width,c.height));}URL.revokeObjectURL(url);return out;
  }
  function findAnimation(){return parameters?.['11:Other']?.['1:Animation']?.['1:AnimationImages'];}
  function applyFrames(frames){
    const a=findAnimation(); if(!a)throw new Error('Seçili şablonda animasyon alanı yok. Animasyon destekli başka bir .bin şablonu yükleyin.');
    const start=(a['3:ImageIndex']??0)-(model.fileType.imageCountOffset||0); const oldCount=a['4:ImagesCount']??0; if(start<0||start>=images.length)throw new Error('Şablon animasyon görselleri bulunamadı.');
    const newImgs=[...images]; for(let i=0;i<Math.min(oldCount,frames.length);i++)newImgs[start+i]=frames[i]; if(frames.length>oldCount){for(let i=oldCount;i<frames.length;i++)newImgs.push(frames[i]);}
    a['3:ImageIndex']=start+(model.fileType.imageCountOffset||0);a['4:ImagesCount']=frames.length;a['2:Speed']=Math.round(1000/Math.max(1,fps));a['3:RepeatCount']=0;images=newImgs;advancedJson=JSON.stringify(parameters,null,2);
  }
  async function handleMedia(e){const file=e.target.files?.[0];if(!file)return;busy=true;error='';mediaName=file.name;try{let frames;if(file.type==='image/gif'||file.name.toLowerCase().endsWith('.gif'))frames=await gifFrames(file);else if(file.type.startsWith('video/'))frames=await videoFrames(file);else throw new Error('GIF veya video seçin.'); if(frames.length>frameCount){const step=frames.length/frameCount;frames=Array.from({length:frameCount},(_,i)=>frames[Math.min(frames.length-1,Math.floor(i*step))]);}applyFrames(frames);}catch(e){error=String(e);}finally{busy=false;}}
  async function loadBinFile(e){const f=e.target.files?.[0];if(!f)return;try{const buf=await f.arrayBuffer();const p=parseWatchFaceBin(buf,model.fileType);parameters=p.parameters;images=p.images;advancedJson=JSON.stringify(parameters,null,2);syncControlsFromParameters();}catch(e){error=String(e);}}
  function applyAdvanced(){try{parameters=JSON.parse(advancedJson);error='';}catch(e){error=String(e);}}
  function addPreviewLayer(base){
    if(showDate && parameters['5:Date']?.['1:MonthAndDayAndYear']?.['2:OneLine']){const n=parameters['5:Date']['1:MonthAndDayAndYear']['2:OneLine'];n['1:TopLeftX']=dateX;n['2:TopLeftY']=dateY;}
    if(showBattery && parameters['9:Battery']?.['1:BatteryText']?.['1:Number']){const n=parameters['9:Battery']['1:BatteryText']['1:Number'];n['1:TopLeftX']=batteryX;n['2:TopLeftY']=batteryY;}
    if(showSteps && parameters['4:Activity']?.['1:Steps']?.['1:Number']){const n=parameters['4:Activity']['1:Steps']['1:Number'];n['1:TopLeftX']=stepsX;n['2:TopLeftY']=stepsY;}
  }
  async function render(){if(!ready||!canvas)return; try{addPreviewLayer();status.animationTime+=50;const result=generatePreview(parameters,images,status,model);const ctx=canvas.getContext('2d');ctx.fillStyle='#000';ctx.fillRect(0,0,W,H);for(const e of result){let img;if(e.canvas)img=e.canvas;else{const im=images[e.imageId-(model.fileType.imageCountOffset||0)];if(!im)continue;img=canvasFromPixels(im);}ctx.drawImage(img,e.position.x,e.position.y);} }catch(e){error=String(e);} }
  function startPreviewLoop(){clearInterval(animationTimer);animationTimer=setInterval(render,100);}
  async function exportBin(){busy=true;error='';try{addPreviewLayer();const bin=writeWatchFaceBin(parameters,images,model.fileType);downloadViaAndroid(bin,'MiBand5_WatchFace.bin');}catch(e){error=String(e);}finally{busy=false;}}
  async function exportJson(){const obj={model:'miband5',parameters,settings:{frameCount,fps,fit,bg,removeWhite,animationX,animationY,timeX,timeY,timeScale,textLayers},imageCount:images.length};const blob=new Blob([JSON.stringify(obj,null,2)],{type:'application/json'});const buf=await blob.arrayBuffer();downloadViaAndroid(new Uint8Array(buf),'MiBand5_WatchFace_Project.json','application/json');}
</script>

<div class="app">
<header><div><h1>Mi Band 5 WatchFace Studio</h1><span>126 × 294 • UIHH / Mi Band 5</span></div><div class="actions"><label class="btn">Şablon .bin<input type="file" accept=".bin" on:change={loadBinFile}/></label><button class="primary" on:click={exportBin} disabled={busy}>.BIN İNDİR</button></div></header>
{#if error}<div class="error">{error}</div>{/if}
<div class="layout">
<section class="previewPanel"><div class="watch"><canvas bind:this={canvas} width={W} height={H}></canvas></div><div class="hint">Önizleme gerçek şablonun parametrelerini kullanır. Animasyonu görmek için bekleyin.</div></section>
<section class="controls">
<div class="card"><h2>1 • GIF / Video</h2><label class="upload">Dosya seç<input bind:this={mediaInput} type="file" accept="image/gif,video/*" on:change={handleMedia}/></label>{#if mediaName}<div class="file">{mediaName}</div>{/if}<div class="grid"><label>Kare sayısı<input type="number" min="1" max="30" bind:value={frameCount}/></label><label>FPS<input type="number" min="1" max="15" bind:value={fps}/></label><label>Yerleşim<select bind:value={fit}><option value="cover">Kapla</option><option value="contain">Sığdır</option></select></label><label>Arka plan<select bind:value={bg}><option value="black">Siyah</option><option value="white">Beyaz</option></select></label></div><label class="check"><input type="checkbox" bind:checked={removeWhite}/> Kenarlardaki beyaz arka planı kaldır</label><div class="grid"><label>X<input type="number" bind:value={animationX} on:input={updateAnimationPos}/></label><label>Y<input type="number" bind:value={animationY} on:input={updateAnimationPos}/></label></div></div>
<div class="card"><h2>2 • Saat</h2><label class="check"><input type="checkbox" bind:checked={showTime}/> HH:MM göster</label><div class="grid"><label>X<input type="number" bind:value={timeX} on:input={updateTimePos}/></label><label>Y<input type="number" bind:value={timeY} on:input={updateTimePos}/></label><label>Ölçek<input type="number" min="0.5" max="2" step="0.1" bind:value={timeScale}/></label></div><small>Not: Ölçek kontrolü şablonun mevcut rakam görsellerini kullanır; tam font boyutu değişimi için gelişmiş JSON veya özel rakam seti kullanılabilir.</small></div>
<div class="card"><h2>3 • Dinamik bilgiler</h2><div class="row"><label class="check"><input type="checkbox" bind:checked={showDate}/> Tarih</label><label class="check"><input type="checkbox" bind:checked={showBattery}/> Pil</label><label class="check"><input type="checkbox" bind:checked={showSteps}/> Adım</label></div><div class="grid"><label>Tarih X<input type="number" bind:value={dateX}/></label><label>Tarih Y<input type="number" bind:value={dateY}/></label><label>Pil X<input type="number" bind:value={batteryX}/></label><label>Pil Y<input type="number" bind:value={batteryY}/></label><label>Adım X<input type="number" bind:value={stepsX}/></label><label>Adım Y<input type="number" bind:value={stepsY}/></label></div></div>
<div class="card"><h2>4 • Yazı katmanları</h2>{#each textLayers as l,i}<div class="layer"><input placeholder="Yazı" bind:value={l.text}/><input type="number" bind:value={l.x} placeholder="X"/><input type="number" bind:value={l.y} placeholder="Y"/><input type="number" bind:value={l.size} placeholder="Boyut"/><input type="color" bind:value={l.color}/><button on:click={()=>removeText(i)}>Sil</button></div>{/each}<button on:click={addText}>+ Yazı ekle</button><small>Bu yazılar her animasyon karesine işlenir; saat/tarih/pil/adım gibi dinamik alanlar ise bandın kendi verisinden beslenir.</small></div>
<div class="card"><h2>5 • Gelişmiş</h2><button on:click={()=>showAdvanced=!showAdvanced}>{showAdvanced ? "JSON'u gizle" : "JSON düzenleyiciyi aç"}</button>{#if showAdvanced}<textarea bind:value={advancedJson} rows="18"></textarea><button class="primary" on:click={applyAdvanced}>JSON'u uygula</button>{/if}<button on:click={exportJson}>Proje JSON indir</button></div>
</section></div>
{#if busy}<div class="busy">İşleniyor…</div>{/if}
</div>
<style>
:global(*){box-sizing:border-box} :global(body){margin:0;background:#0d0d0f;color:#eee;font-family:system-ui,-apple-system,Segoe UI,sans-serif}.app{min-height:100vh}header{position:sticky;top:0;z-index:20;padding:12px 16px;background:#151518ee;backdrop-filter:blur(10px);border-bottom:1px solid #2a2a2e;display:flex;justify-content:space-between;align-items:center;gap:12px}h1{font-size:18px;margin:0}header span{font-size:11px;color:#999}.actions{display:flex;gap:8px}.btn,button{border:1px solid #39393e;background:#202025;color:#eee;border-radius:9px;padding:9px 12px;font-weight:600}.btn{display:inline-flex;align-items:center;cursor:pointer}.btn input,.upload input{display:none}.primary{background:#fff;color:#000;border-color:#fff}.error{margin:10px 16px;padding:10px;border:1px solid #7b3030;background:#2a1515;color:#ffb0b0;border-radius:8px}.layout{display:grid;grid-template-columns:360px 1fr;max-width:1200px;margin:auto;min-height:calc(100vh - 60px)}.previewPanel{padding:24px;display:flex;flex-direction:column;align-items:center;position:sticky;top:61px;height:calc(100vh - 61px)}.watch{height:min(74vh,620px);aspect-ratio:126/294;background:#000;border-radius:28px;padding:12px;box-shadow:0 0 0 1px #303036,0 20px 60px #000}.watch canvas{width:100%;height:100%;image-rendering:auto;background:#000;border-radius:20px}.hint{font-size:11px;color:#888;margin-top:12px;text-align:center}.controls{padding:18px 18px 60px;display:flex;flex-direction:column;gap:12px}.card{background:#16161a;border:1px solid #29292e;border-radius:12px;padding:14px}.card h2{font-size:14px;margin:0 0 12px}.upload{display:block;text-align:center;padding:12px;border:1px dashed #555;border-radius:9px;cursor:pointer}.file{font-size:12px;color:#aaa;margin-top:8px;overflow:hidden;text-overflow:ellipsis}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;margin-top:10px}.grid label{display:flex;flex-direction:column;gap:5px;font-size:11px;color:#aaa}input,select,textarea{width:100%;background:#0f0f12;color:#eee;border:1px solid #36363c;border-radius:7px;padding:8px}textarea{font-family:monospace;font-size:11px;margin-top:10px;resize:vertical}.check{display:flex;gap:8px;align-items:center;font-size:12px;margin-top:10px}.check input{width:auto}.row{display:flex;gap:14px;flex-wrap:wrap}.layer{display:grid;grid-template-columns:1fr 55px 55px 60px 36px 45px;gap:5px;margin-bottom:7px}.layer button{padding:6px;font-size:11px}.layer input{padding:6px}.card small{display:block;color:#777;font-size:10px;line-height:1.4;margin-top:9px}.busy{position:fixed;inset:0;background:#000a;display:grid;place-items:center;font-size:18px;z-index:100}
@media(max-width:800px){header{align-items:flex-start}.layout{display:block}.previewPanel{position:relative;top:0;height:auto;padding:18px}.watch{height:58vh;max-height:560px}.controls{padding:10px 12px 40px}.actions .btn{display:none}.layer{grid-template-columns:1fr 48px 48px 52px 32px 40px}}
</style>
