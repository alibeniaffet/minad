# Mi Band 5 WatchFace Studio

Android uygulaması: GIF veya videoyu Mi Band 5 (126x294) animasyonlu watch-face `.bin` dosyasına dönüştürmek ve şablon üzerinde düzenlemek için hazırlanmıştır.

## Özellikler

- GIF yükleme ve karelerini çıkarma
- MP4/WebM vb. video yükleme ve kare örnekleme
- 126x294 hedef ekran
- Kapla / sığdır
- Siyah / beyaz arka plan
- Kenarlardan gelen beyaz arka planı flood-fill ile kaldırma
- Animasyon FPS ve kare sayısı kontrolü
- Animasyon X/Y konumu
- Gerçek Mi Band 5 UIHH `.bin` şablonunu kullanma
- Saat HH:MM konumu
- Tarih / pil / adım gibi dinamik alanları şablon üzerinden açma ve konumlandırma
- Her kareye işlenen yazı katmanları ekleme/silme
- Gelişmiş JSON düzenleyici
- `.bin` dosyasını Android Downloads/MiBand5WatchFaceStudio içine indirme
- Şablon `.bin` yükleme
- Proje JSON dışa aktarma

## Neden şablon kullanıyor?

Mi Band 5 UIHH formatı basit bir PNG/GIF formatı değildir. Watch-face; parametreler, görsel kaynakları ve animasyon tanımları içeren bir binary yapıdır. Proje `watchface-js` kütüphanesinin Mi Band 5 desteğini kullanır. Kütüphane Mi Band 5'i destekler ve `writeWatchFaceBin` ile `.bin` üretimi sağlar.

## GitHub Actions ile APK

1. Bu klasörü GitHub repository'sine yükle.
2. `.github/workflows/build.yml` dosyası otomatik olarak çalışır veya Actions > Mi Band 5 WatchFace Studio APK > Run workflow ile elle başlatılır.
3. Build tamamlanınca `MiBand5-WatchFace-Studio-APK` artifact'ini indir.
4. Artifact içindeki `app-debug.apk` dosyasını Android telefona kur.

Workflow Node.js ile web editörü derler, oluşan web dosyalarını Android assets içine kopyalar, Android SDK + Gradle ile debug APK üretir.

## Notlar

- İlk sürüm fiziksel Mi Band 5 senkronizasyonunu uygulamanın içine koymaz; `.bin` üretir. Üretilen dosyayı Notify veya Mi Band 5 watch-face yükleyebilen başka bir araçla yükleyebilirsin.
- Çok fazla kare ve yüksek renkli büyük görseller `.bin` boyutunu ciddi artırabilir. Bu yüzden uygulama varsayılan olarak 12 kare / 10 FPS ile gelir.
- `watchface-js` GPL-3.0-only lisanslıdır; dağıtım yaparken lisans şartlarına uyulmalıdır.
