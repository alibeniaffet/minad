package com.eyaarc.miband5studio;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.widget.Toast;
import java.io.*;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST=9001;

    @Override public void onCreate(Bundle b){super.onCreate(b);
        webView=new WebView(this); setContentView(webView);
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p){
                if(fileCallback!=null) fileCallback.onReceiveValue(null); fileCallback=cb;
                Intent i=p.createIntent(); i.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,FILE_REQUEST); return true;
            }
        });
        webView.addJavascriptInterface(new Bridge(),"AndroidBridge");
        webView.loadUrl("file:///android_asset/web/index.html");
    }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==FILE_REQUEST&&fileCallback!=null){Uri[] res=null;if(c==RESULT_OK&&d!=null){if(d.getClipData()!=null){int n=d.getClipData().getItemCount();res=new Uri[n];for(int i=0;i<n;i++)res[i]=d.getClipData().getItemAt(i).getUri();}else if(d.getData()!=null)res=new Uri[]{d.getData()};}fileCallback.onReceiveValue(res);fileCallback=null;}}
    public class Bridge{
        @JavascriptInterface public String getTemplateBase64(){try{InputStream in=getAssets().open("template/template.bin");ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();return Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);}catch(Exception e){return "";}}
        @JavascriptInterface public void saveFile(String name,String base64,String mime){runOnUiThread(()->{try{byte[] data=Base64.decode(base64,Base64.DEFAULT);ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,name);v.put(MediaStore.Downloads.MIME_TYPE,mime);v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/MiBand5WatchFaceStudio");Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(u==null)throw new IOException("Downloads kaydı oluşturulamadı");OutputStream os=getContentResolver().openOutputStream(u);os.write(data);os.close();Toast.makeText(MainActivity.this,"İndirildi: Downloads/MiBand5WatchFaceStudio/"+name,Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(MainActivity.this,"Kaydetme hatası: "+e.getMessage(),Toast.LENGTH_LONG).show();}});}
    }
}
