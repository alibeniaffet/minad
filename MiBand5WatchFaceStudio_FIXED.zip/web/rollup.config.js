import svelte from 'rollup-plugin-svelte';
import resolve from '@rollup/plugin-node-resolve';
import commonjs from '@rollup/plugin-commonjs';
import json from '@rollup/plugin-json';
import terser from '@rollup/plugin-terser';

export default {
  input: 'src/main.js',
  output: { file: 'dist/bundle.js', format: 'iife', name: 'MiBand5Studio', sourcemap: false },
  plugins: [
    svelte({ compilerOptions: { dev: false } }),
    resolve({ browser: true, dedupe: ['svelte'] }),
    commonjs(), json(),
    terser()
  ]
};
