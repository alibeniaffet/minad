export function clamp(v,min,max){return Math.max(min,Math.min(max,v));}
export function fitRect(sw,sh,dw,dh,mode='cover'){
  const s=mode==='contain'?Math.min(dw/sw,dh/sh):Math.max(dw/sw,dh/sh);
  return {w:Math.round(sw*s),h:Math.round(sh*s)};
}
export function pixelsFromCanvas(canvas){const c=canvas.getContext('2d',{willReadFrequently:true});return {width:canvas.width,height:canvas.height,pixels:new Uint8Array(c.getImageData(0,0,canvas.width,canvas.height).data)};}
export function canvasFromPixels(img){const c=document.createElement('canvas');c.width=img.width;c.height=img.height;c.getContext('2d').putImageData(new ImageData(new Uint8ClampedArray(img.pixels),img.width,img.height),0,0);return c;}
export function downloadViaAndroid(data,name,mime='application/octet-stream'){
  const bytes=data instanceof Uint8Array?data:new Uint8Array(data); let binary=''; const chunk=0x8000;
  for(let i=0;i<bytes.length;i+=chunk) binary+=String.fromCharCode(...bytes.subarray(i,Math.min(i+chunk,bytes.length)));
  const b64=btoa(binary); if(window.AndroidBridge?.saveFile){window.AndroidBridge.saveFile(name,b64,mime);return;}
  const blob=new Blob([bytes],{type:mime}); const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
